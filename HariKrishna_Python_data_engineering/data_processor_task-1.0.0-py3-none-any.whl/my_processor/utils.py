import re

class InvalidMemberDataError(Exception):
    """Custom exception raised when member data fails validation."""
    pass

# Email regex matching standard name@domain.com structures
EMAIL_REGEX = r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$"
# Phone regex matching 3-digit groups (e.g., 555-0101)
PHONE_REGEX = r"^\d{3}-\d{4}$"

def validate_email(email: str) -> bool:
    """Validates email format using regular expressions."""
    if not email:
        return False
    return bool(re.match(EMAIL_REGEX, email.strip()))

def validate_phone(phone: str) -> bool:
    """Validates phone format (XXX-XXXX) using regular expressions."""
    if not phone:
        return False
    return bool(re.match(PHONE_REGEX, phone.strip()))
