from typing import List, Dict, Any, Optional
from my_processor.utils import validate_email, validate_phone, InvalidMemberDataError

class Member:
    def __init__(self, name: str, email: str, phone: str):
        """Initializes a Member object with clean instance variables."""
        self.name = name.strip()
        self.email = email.strip()
        self.phone = phone.strip()

    def __str__(self) -> str:
        """String representation matching the usage example."""
        return f"Member(Name: {self.name}, Email: {self.email}, Phone: {self.phone})"

def process_raw_data(raw_data: List[Dict[str, Any]]) -> List[Member]:
    """Cleans, validates, and transforms raw dictionary data into Member objects."""
    valid_members = []
    
    for record in raw_data:
        # Gracefully extract keys or fallback to None string representations
        name = record.get("name", "Unknown")
        email = record.get("email", "")
        phone = record.get("phone", "")
        
        print(f"Processing member: {name}...")
        
        try:
            # Enforce validation requirements
            if not validate_email(email):
                raise InvalidMemberDataError(f"Invalid email for member '{name}'.")
            if not validate_phone(phone):
                raise InvalidMemberDataError(f"Invalid phone number for member '{name}'.")
                
            # Instantiate and store valid OOP model
            new_member = Member(name, email, phone)
            valid_members.append(new_member)
            print("Validation Successful.")
            
        except InvalidMemberDataError as error:
            print(f"Shell Python Error: {error} Skipping.")
        except Exception as system_error:
            print(f"Unexpected System Error tracking '{name}': {system_error}. Skipping.")

    print(f"\nSummary: {len(valid_members)} members processed successfully.")
    return valid_members

def filter_members_by_domain(members: List[Member], domain: str) -> List[Member]:
    """Uses a lambda function with filter() to slice membership by email domain."""
    return list(filter(lambda m: m.email.endswith(domain), members))
