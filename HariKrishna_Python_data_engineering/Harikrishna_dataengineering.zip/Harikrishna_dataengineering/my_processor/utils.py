import re
from typing import Optional

class InvalidMemberDataError(Exception):
    """Custom exception raised when member data fails validation."""
    pass

# Email regex matching standard name@domain.com structures
EMAIL_REGEX = re.compile(r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$")
# Phone regex matching standard assignment 3-4 digit hyphenation patterns (e.g., 555-0101)
PHONE_REGEX = re.compile(r"^\d{3}-\d{4}$")

def validate_email(email: Optional[str]) -> bool:
    """Validates email format safely handling Python None types."""
    if email is None or not isinstance(email, str):
        return False
    return bool(EMAIL_REGEX.match(email.strip()))

def validate_phone(phone: Optional[str]) -> bool:
    """Validates phone format safely handling Python None types."""
    if phone is None or not isinstance(phone, str):
        return False
    return bool(PHONE_REGEX.match(phone.strip()))
