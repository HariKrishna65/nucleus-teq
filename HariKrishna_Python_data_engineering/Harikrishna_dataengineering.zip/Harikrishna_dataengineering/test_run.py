from my_processor.core import process_raw_data, filter_members_by_domain

# Assignment test dataset array input
raw_members = [
    {"name": "John Doe", "email": "john.doe@example.com", "phone": "555-0101"},
    {"name": "Jane Smith", "email": "jane.smith@...com", "phone": "555-0102"},
    {"name": "InvalidData", "email": "bad-email@", "phone": "555-9999"}
]

if __name__ == "__main__":
    print("--- Starting Pipeline ---")
    processed_list = process_raw_data(raw_members)
    
    print("\n--- Testing Lambda Filtering (.com domain) ---")
    filtered = filter_members_by_domain(processed_list, "example.com")
    for member in filtered:
        print(f"Found: {member}")
